-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: extremesports
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `localitate`
--

DROP TABLE IF EXISTS `localitate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `localitate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(45) NOT NULL,
  `id_regiune` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idlocalitate_UNIQUE` (`id`),
  UNIQUE KEY `localitatecol_UNIQUE` (`nume`),
  KEY `id_regiune_idx` (`id_regiune`),
  CONSTRAINT `id_regiune` FOREIGN KEY (`id_regiune`) REFERENCES `regiune` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localitate`
--

LOCK TABLES `localitate` WRITE;
/*!40000 ALTER TABLE `localitate` DISABLE KEYS */;
INSERT INTO `localitate` VALUES (1,'Predeal',1),(2,'Sinaia',1),(3,'Busteni',1),(4,'La Plagne',2),(5,'Val Thorens',2),(6,'Courchevel',2),(7,'Davos Dorf',3),(8,'Thassos',4);
/*!40000 ALTER TABLE `localitate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regiune`
--

DROP TABLE IF EXISTS `regiune`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regiune` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(45) NOT NULL,
  `id_tara` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idregiune_UNIQUE` (`id`),
  UNIQUE KEY `regiunecol_UNIQUE` (`nume`),
  KEY `id_tara_idx` (`id_tara`),
  CONSTRAINT `id_tara` FOREIGN KEY (`id_tara`) REFERENCES `tara` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regiune`
--

LOCK TABLES `regiune` WRITE;
/*!40000 ALTER TABLE `regiune` DISABLE KEYS */;
INSERT INTO `regiune` VALUES (1,'Brasov',1),(2,'Les 3 Vallées',6),(3,'Davos',7),(4,'Kavala',5),(5,'Brasov2',13),(6,'Brasov3',14);
/*!40000 ALTER TABLE `regiune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sport`
--

DROP TABLE IF EXISTS `sport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(45) NOT NULL,
  `perioada_start` varchar(20) DEFAULT NULL,
  `perioada_stop` varchar(20) DEFAULT NULL,
  `cost_zi` double DEFAULT NULL,
  `id_localitate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idsport_UNIQUE` (`id`),
  KEY `id_localitate_idx` (`id_localitate`),
  CONSTRAINT `id_localitate` FOREIGN KEY (`id_localitate`) REFERENCES `localitate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sport`
--

LOCK TABLES `sport` WRITE;
/*!40000 ALTER TABLE `sport` DISABLE KEYS */;
INSERT INTO `sport` VALUES (1,'ski','decembrie','martie',300,1),(2,'ski','decembrie','martie',250,2),(3,'atv','ianuarie','decembrie',100,3),(4,'ski','decembrie','februarie',500,4),(5,'ski','ianuarie','martie',600,5),(6,'ski','decembrie','martie',400,6),(7,'parapanta','aprilie','septembrie',300,7),(8,'scuba-diving','iunie','septembrie',500,8),(9,'atv','ianuarie','septembrie',300,1),(13,'atv3','ianuarie2','decembrie2',300,NULL);
/*!40000 ALTER TABLE `sport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tara`
--

DROP TABLE IF EXISTS `tara`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tara` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idtara_UNIQUE` (`id`),
  UNIQUE KEY `taracol_UNIQUE` (`nume`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tara`
--

LOCK TABLES `tara` WRITE;
/*!40000 ALTER TABLE `tara` DISABLE KEYS */;
INSERT INTO `tara` VALUES (7,'Elvetia'),(6,'Franta'),(5,'Grecia'),(1,'Romania'),(13,'Romania2'),(14,'Romania3');
/*!40000 ALTER TABLE `tara` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-17  9:00:52
